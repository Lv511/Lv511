#include <openpose/core/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WCvMatToOpInput);
    DEFINE_TEMPLATE_DATUM(WCvMatToOpOutput);
    DEFINE_TEMPLATE_DATUM(WKeepTopNPeople);
    DEFINE_TEMPLATE_DATUM(WKeypointScaler);
    DEFINE_TEMPLATE_DATUM(WOpOutputToCvMat);
    DEFINE_TEMPLATE_DATUM(WScaleAndSizeExtractor);
    DEFINE_TEMPLATE_DATUM(WVerbosePrinter);
}
